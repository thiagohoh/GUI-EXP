import javax.swing.*;

/**
 * Created by Thiago on 17/05/2016.
 */
public class Main {
    public static void main(String[] args) {
        Telinha t = new Telinha();
        t.setVisible(true);
        t.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        t.setSize(1000,1000);
        t.setLocationRelativeTo(null);



    }
}
