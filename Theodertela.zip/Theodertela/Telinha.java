import javax.swing.*;
import java.awt.*;

/**
 * Created by Thiago on 17/05/2016.
 */
public class Telinha extends JFrame {
    private JPanel panel1;
    private JLabel aaaa;
    private  JLabel back = new JLabel(new ImageIcon("C:\\Users\\Thiago\\JASr\\wallhaven-6598.jpg"));

    public  Telinha (){
        super("telaa");
        add(aaaa);
        //add(panel1);
        add(back);
        back.setLayout(new FlowLayout());
        //panel1.setLocation(400,400);
        //panel1.setSize(200,200);
        aaaa.setVisible(true);
        aaaa.setSize(350,350);
        aaaa.setLocation(250,100);
        aaaa.setText("JAUM VIADAO");






    }

}
